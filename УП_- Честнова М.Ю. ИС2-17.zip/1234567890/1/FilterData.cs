﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    static class FilterData
    {
        public static void filter(BindingSource binding, ComboBox comboBox, TextBox textBox)
        {
            try
            {
                binding.Filter = $"{comboBox.SelectedItem} = '{textBox.Text}'";
            }
            catch(Exception e)
            {
                binding.Filter = "";
            }
            
            
            if (String.IsNullOrEmpty(textBox.Text))
                binding.Filter = "";
        }

        // заполняет выпадающий список названиями колонок
        public static void fillCombobox(ComboBox comboBox, DataGridView dataGrid)
        {
            foreach (DataGridViewColumn column in dataGrid.Columns)
            {
                comboBox.Items.Add(column.HeaderText);
            }
            comboBox.SelectedIndex = 0;
        }
    }
}
