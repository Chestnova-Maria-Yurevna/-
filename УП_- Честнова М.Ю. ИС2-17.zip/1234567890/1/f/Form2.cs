﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Application = System.Windows.Forms.Application;
using DataTable = System.Data.DataTable;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
        SqlConnection taty = new SqlConnection(@"Data Source=DESKTOP-O0P3PUP\SQLEXPRESS;Initial Catalog = t_salon; Integrated Security = True");
        SqlCommand obr = new SqlCommand();

        string table = "";

        private void Select()
        {
            obr.Connection = taty;
           SqlDataAdapter ad = new SqlDataAdapter(obr);
            DataTable tbl = new DataTable();
            ad.Fill(tbl);
            dataGridView1.DataSource = tbl;
        }
       private void connect(string a)
        {
           taty.Open();
           obr.CommandText = (a);
           obr.ExecuteNonQuery();
           taty.Close();
        }

        private void emploeeyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            obr.CommandText = ("SELECT * FROM [Данные]");
            table = "Данные";

            Select();
        }

        private void сотрудникиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            obr.CommandText = ("SELECT * FROM [Сотрудники]");
            table = "Сотрудники";

            Select();
        }

        private void клиентыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            obr.CommandText = ("SELECT * FROM [Клиенты]");
            table = "Клиенты";

            Select();
        }

        private void услугиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            obr.CommandText = ("SELECT * FROM [Услуги]");
            table = "Услуги";

            Select();
        }

        private void картыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            obr.CommandText = ("SELECT * FROM [Карты]");
            table = "Карты";

            Select();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}