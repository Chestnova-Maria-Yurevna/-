﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form3 : Form
    {
        private Dictionary<int, int> newIds = new Dictionary<int, int>();

        public Form3()
        {
            InitializeComponent();
        }

        private void GenerateDefaultCreds()
        {
            Guid login = Guid.NewGuid();
            Guid password = Guid.NewGuid();

            using (SqlConnection con = Utils.GetDBConnection())
            {
                SqlCommand clearCommand = new SqlCommand("delete from Данные where Код_сотрудника not in (select Код_сотрудника from Сотрудники)", con);
                clearCommand.ExecuteNonQuery();
                
                foreach (var item in this.newIds)
                {
                    SqlCommand sql = new SqlCommand($"insert into Данные values({item.Key}, '{login}', '{password}', {item.Value})", con);
                    sql.ExecuteNonQuery();
                }

            }
            this.newIds.Clear();
        }

        private void сотрудникиBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        { 
            try
            {
                this.GenerateDefaultCreds();       
                this.Validate();
                this.сотрудникиBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.t_salonDataSet);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }   
        }

        private void fillLists()
        {
            Utils.fillList(
                "select Должность.Наименование as Должность from [Сотрудники] join [Должность] on Сотрудники.Код_должность = Должность.Код_должности",
                "Должность",
                сотрудникиDataGridView
                );
            Utils.fillList(
                "select Пол.Значение as Пол from [Сотрудники] join [Пол] on Сотрудники.Пол = Пол.Код_п",
                "Пол",
                сотрудникиDataGridView
                );
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "t_salonDataSet.Сотрудники". При необходимости она может быть перемещена или удалена.
            this.сотрудникиTableAdapter.Fill(this.t_salonDataSet.Сотрудники);

            FilterData.fillCombobox(comboBox1, сотрудникиDataGridView);

            fillLists();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            // кнопка обновить
            this.сотрудникиTableAdapter.Fill(this.t_salonDataSet.Сотрудники);
            fillLists();
        }

        private void queryTextBox_TextChanged(object sender, EventArgs e)
        {
            FilterData.filter(сотрудникиBindingSource, comboBox1, queryTextBox);
        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
            FormAdd formAdd = new FormAdd(сотрудникиBindingSource);
            formAdd.ShowDialog();
            сотрудникиDataGridView.Update();
            сотрудникиDataGridView.Refresh();
            int index = сотрудникиBindingNavigator.BindingSource.Position;
            int id = (int)сотрудникиDataGridView.Rows[index].Cells[0].Value;
            DataRowView data = (DataRowView)сотрудникиBindingNavigator.BindingSource.Current;
            int role = (int)data[5];
            this.newIds.Add(id, role);
        }

        private void сотрудникиDataGridView_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
           
        }

        private void bindingNavigatorDeleteItem_Click(object sender, EventArgs e)
        {
            
        }
    }
}
