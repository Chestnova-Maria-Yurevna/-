﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form7 : Form
    {
        
        public Form7()
        {
            InitializeComponent();
        }

       

        private void оборудованиеBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            
            this.оборудованиеBindingSource.EndEdit();

            this.tableAdapterManager.UpdateAll(this.t_salonDataSet);
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "t_salonDataSet.Оборудование". При необходимости она может быть перемещена или удалена.
            this.оборудованиеTableAdapter.Fill(this.t_salonDataSet.Оборудование);
            FilterData.fillCombobox(comboBox1, оборудованиеDataGridView);

            Utils.fillList("select Поставщики.Наименование as Поставщик from [Оборудование] join [Поставщики] on Оборудование.Код_поставщика = Поставщики.Код_поставщика", "Поставщик", оборудованиеDataGridView);
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            // кнопка обновить
            this.оборудованиеTableAdapter.Fill(this.t_salonDataSet.Оборудование);
            Utils.fillList("select Поставщики.Наименование as Поставщик from [Оборудование] join [Поставщики] on Оборудование.Код_поставщика = Поставщики.Код_поставщика", "Поставщик", оборудованиеDataGridView);
        }

        private void queryTextBox_TextChanged(object sender, EventArgs e)
        {
            FilterData.filter(оборудованиеBindingSource, comboBox1, queryTextBox);
        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
            FormAdd formAdd = new FormAdd(оборудованиеBindingSource);
            formAdd.ShowDialog();
            оборудованиеDataGridView.Update();
            оборудованиеDataGridView.Refresh();
            Utils.fillList("select Поставщики.Наименование as Поставщик from [Оборудование] join [Поставщики] on Оборудование.Код_поставщика = Поставщики.Код_поставщика", "Поставщик", оборудованиеDataGridView);
        }

    }
}
