﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class FormAdd : Form
    {
        private BindingSource bindingSource;
        
        public FormAdd(BindingSource bindingSource)
        {
            this.bindingSource = bindingSource;
            InitializeComponent();

            this.bindingNavigator.BindingSource = bindingSource;
            generateComponents();
        }

        // генератор полей
        private void generateComponents()
        {
            DataRowView row = (DataRowView)(bindingNavigator.BindingSource.Current);

            foreach(DataColumn column in row.DataView.Table.Columns.Cast<DataColumn>())
            {
                TextBox textBox = new TextBox();
                Label label = new Label();

                label.Text = column.ColumnName;
                textBox.Text = " ";
                
                textBox.DataBindings.Add("Text", bindingSource, column.ColumnName);

                flowLayoutPanel1.Controls.Add(label);
                flowLayoutPanel1.Controls.Add(textBox);
            }

            row[0] = bindingNavigator.BindingSource.Count;

        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // обработка события закрытия окна
        private void FormAdd_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                bindingNavigator.BindingSource.EndEdit();
                e.Cancel = false;
            }
            catch (Exception ex)
            {
                // вывод сообщений об ошибках
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                e.Cancel = true;
            }
        }

        // отмена
        private void cancelButton_Click(object sender, EventArgs e)
        {
            // удаление всех привязок
            bindingNavigator.BindingSource.RemoveCurrent();
            //закрытие окна
            this.Close();
        }
    }
}
