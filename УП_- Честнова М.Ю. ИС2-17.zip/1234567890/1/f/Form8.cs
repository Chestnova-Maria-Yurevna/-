﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }
        private void fillLists()
        {
            Utils.fillList(
                "SELECT CONCAT(Страна.Название, ', г.', Город.Название, ' р-н ', Район.Название, ' ул.', Улица.Название) as Адрес " +
             "FROM [Поставщики] JOIN " +
             "[Адрес] ON Поставщики.Адрес = Адрес.Код_адреса JOIN " +
             "[Город] ON Адрес.Код_города = Город.Код_города JOIN " +
             "[Район] ON Адрес.Код_района = Район.Код_района JOIN " +
             "[Улица] ON Адрес.Код_улицы = Улица.Код_улицы JOIN " +
             "[Страна] ON Адрес.Код_страны = Страна.Код_страны ",
                "Адрес",
                поставщикиDataGridView
                );
        }

        private void поставщикиBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.поставщикиBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.t_salonDataSet);

        }

        private void Form8_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "t_salonDataSet.Поставщики". При необходимости она может быть перемещена или удалена.
            this.поставщикиTableAdapter.Fill(this.t_salonDataSet.Поставщики);
            FilterData.fillCombobox(comboBox1, поставщикиDataGridView);
            fillLists();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            // кнопка обновить
            this.поставщикиTableAdapter.Fill(this.t_salonDataSet.Поставщики);
            fillLists();
        }

        private void queryTextBox_TextChanged(object sender, EventArgs e)
        {
            FilterData.filter(поставщикиBindingSource, comboBox1, queryTextBox);
        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
            FormAdd formAdd = new FormAdd(поставщикиBindingSource);
            formAdd.ShowDialog();
            поставщикиDataGridView.Update();
            поставщикиDataGridView.Refresh();
        }
    }
}
