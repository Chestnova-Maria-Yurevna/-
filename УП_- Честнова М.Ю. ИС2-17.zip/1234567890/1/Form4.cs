﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        // сохранить 
        private void клиенты2BindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            try
            {
                this.Validate();
                this.клиенты2BindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.t_salonDataSet);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            

        }

        private void fillLists()
        {
            Utils.fillList(
                "select Услуги.Наименование_услуг as Услуга from [Клиенты] join [Услуги] on Клиенты.Наименование_услуги = Услуги.Код_услуги",
                "Услуга",
                клиенты2DataGridView
                );
            Utils.fillList(
                "select Пол.Значение as Пол from [Клиенты] join [Пол] on Клиенты.Пол = Пол.Код_п",
                "Пол",
                клиенты2DataGridView
                );
            Utils.fillList(
                "select CONCAT(Сотрудники.Фамилия, ' ', LEFT(Сотрудники.Имя,1), '.', LEFT(Сотрудники.Отчество, 1), '.') " +
                "as Сотрудник from [Клиенты] join [Сотрудники] on Клиенты.Код_сотрудника = Сотрудники.Код_сотрудника",
                "Сотрудник",
                клиенты2DataGridView
                );
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "t_salonDataSet.Обслуживание_клиентов". При необходимости она может быть перемещена или удалена.
            this.обслуживание_клиентовTableAdapter.Fill(this.t_salonDataSet.Обслуживание_клиентов);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "t_salonDataSet.Клиенты2". При необходимости она может быть перемещена или удалена.
            this.клиенты2TableAdapter.Fill(this.t_salonDataSet.Клиенты2);

            FilterData.fillCombobox(comboBox1, клиенты2DataGridView);
            FilterData.fillCombobox(comboBox2, обслуживание_клиентовDataGridView);
            fillLists();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            // кнопка обновить
            this.клиенты2TableAdapter.Fill(this.t_salonDataSet.Клиенты2);
            fillLists();
        }


        private void обслуживание_клиентовDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        //ддобавить и удалить 
        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
            FormAdd formAdd = new FormAdd(клиенты2BindingNavigator.BindingSource);
            formAdd.ShowDialog();
            клиенты2DataGridView.Update();
            клиенты2DataGridView.Refresh();
            
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            FormAdd formAdd = new FormAdd(bindingNavigator1.BindingSource);
            formAdd.ShowDialog();
            обслуживание_клиентовDataGridView.Update();
            обслуживание_клиентовDataGridView.Refresh();
        }

        private void клиенты2DataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            FilterData.filter(обслуживание_клиентовBindingSource, comboBox2, textBox1);
        }

        //поиск
        private void queryTextBox_TextChanged(object sender, EventArgs e)
        {
            FilterData.filter(клиенты2BindingSource, comboBox1, queryTextBox);
        }

        private void toolStripButton8_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.обслуживание_клиентовBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.t_salonDataSet);
        }

        private void toolStripButton9_Click(object sender, EventArgs e)
        {
            this.обслуживание_клиентовTableAdapter.Fill(this.t_salonDataSet.Обслуживание_клиентов);
            fillLists();
        }

        private void клиенты2BindingNavigator_RefreshItems(object sender, EventArgs e)
        {

        }

        private void bindingNavigatorDeleteItem_Click(object sender, EventArgs e)
        {

        }
    }
}
