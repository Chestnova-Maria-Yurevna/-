﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void услугиBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.услугиBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.t_salonDataSet);

        }

        private void Form5_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "t_salonDataSet.Услуги". При необходимости она может быть перемещена или удалена.
            this.услугиTableAdapter.Fill(this.t_salonDataSet.Услуги);

            FilterData.fillCombobox(comboBox1, услугиDataGridView);
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            // кнопка обновить
            this.услугиTableAdapter.Fill(this.t_salonDataSet.Услуги);
        }

        private void queryTextBox_TextChanged(object sender, EventArgs e)
        {
            FilterData.filter(услугиBindingSource, comboBox1, queryTextBox);
        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
            FormAdd formAdd = new FormAdd(услугиBindingSource);
            formAdd.ShowDialog();
            услугиDataGridView.Update();
            услугиDataGridView.Refresh();
        }
    }
}
