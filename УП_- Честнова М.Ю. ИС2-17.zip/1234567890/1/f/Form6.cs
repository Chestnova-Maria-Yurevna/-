﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void fillLists()
        {
            Utils.fillList(
                "select Поставщики.Наименование as Поставщик from [Материалы] join [Поставщики] on Материалы.Код_поставщика = Поставщики.Код_поставщика",
                "Поставщик",
                материалыDataGridView
                );
            
        }

        private void материалыBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.материалыBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.t_salonDataSet);

        }

        private void Form6_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "t_salonDataSet.Материалы". При необходимости она может быть перемещена или удалена.
            this.материалыTableAdapter.Fill(this.t_salonDataSet.Материалы);

            FilterData.fillCombobox(comboBox1, материалыDataGridView);
            fillLists();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            // кнопка обновить
            this.материалыTableAdapter.Fill(this.t_salonDataSet.Материалы);
            fillLists();
        }

        private void queryTextBox_TextChanged(object sender, EventArgs e)
        {
            FilterData.filter(материалыBindingSource, comboBox1, queryTextBox);
        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
            FormAdd formAdd = new FormAdd(материалыBindingSource);
            formAdd.ShowDialog();
            материалыDataGridView.Update();
            материалыDataGridView.Refresh();
        }
    }
}
