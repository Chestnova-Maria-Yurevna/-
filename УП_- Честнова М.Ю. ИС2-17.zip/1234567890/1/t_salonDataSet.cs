﻿namespace WindowsFormsApp1
{


    public partial class t_salonDataSet
    {
        partial class DataTable1DataTable
        {
        }
    }
}

namespace WindowsFormsApp1.t_salonDataSetTableAdapters {
    
    
    public partial class ОборудованиеTableAdapter {
    }
}
