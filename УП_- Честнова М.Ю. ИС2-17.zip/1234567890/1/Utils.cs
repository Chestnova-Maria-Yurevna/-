﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public static class Utils
    {
        // получить соеденение с бд
        public static SqlConnection GetDBConnection()
        {
            string DB = @"Data Source=DESKTOP-O0P3PUP\SQLEXPRESS;
                    Initial Catalog = t_salon;
                    Integrated Security = True";//Настройка параметров подключения

            SqlConnection connectDB = new SqlConnection(DB);
            connectDB.Open();//Открываем соединение с БД
            return connectDB;
        }

        // получить индекс колонки по ее шапке
        public static int getColumnByHeader(string header, DataGridView dataGridView)
        {
            int index = 0;
            foreach(DataGridViewColumn column in dataGridView.Columns.Cast<DataGridViewColumn>())
            {
                if (column.HeaderText.Equals(header)) return index;
                index++;
            }

            return -1;
        }

        // выполняет запрос ии заполняет колонки
        public static void fillList(string query, string column, DataGridView dataGridView)
        {

            using (SqlConnection conn = GetDBConnection())
            {
                SqlCommand sql = new SqlCommand(query, conn);

                

                SqlDataReader reader = sql.ExecuteReader();
                try
                {
                    int i = 0;
                    while (reader.Read())
                    {
                        int columnIndex = getColumnByHeader(column, dataGridView);
                        
                        dataGridView.Rows[i].Cells[columnIndex].Value = (string)reader[column];
                        i++;
                    }
                }
                finally
                {
                    reader.Close();
                }
            }


        }
    }
}
