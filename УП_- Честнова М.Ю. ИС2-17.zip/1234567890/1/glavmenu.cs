﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Linq;

namespace WindowsFormsApp1
{
    public partial class glavmenu : Form
    {
        private int role;
        private List<Button> buttons = new List<Button>();
        //private Dictionary<int, int[]> roles_to_buttons = new Dictionary<int, int[]>
        //    {
        //        {1, new int[]{2, 3, 4, 8 } },
        //        {2, new int[]{2, 3, 4, 7 } },
        //        {3, new int[]{4, 5, 6, 8 } },
        //        {4, new int[]{2, 3, 4, 8 } },
        //        {5, new int[]{1, 2, 3, 4, 5, 6, 7, 8} },
        //        {6, new int[]{2, 3, 4, 8 } },
        //        {7, new int[]{4, 5, 6, 8 } },
        //    };
        
        public glavmenu(int role)
        {
            this.Role = role;
            InitializeComponent();
            //etupRoleButtons();
        }

        private void fillButtonsList()
        {
            this.buttons.Add(button1);
            this.buttons.Add(button2);
            this.buttons.Add(button3);
            this.buttons.Add(button4);
            this.buttons.Add(button5);
            this.buttons.Add(button6);
            this.buttons.Add(button7);
            this.buttons.Add(button8);

            foreach(var button in this.buttons)
            {
                button.Enabled = false;
            }
        }

        //private void setupRoleButtons()
        //{
        //    fillButtonsList();

        //    var rules = from rule in this.roles_to_buttons where rule.Key.Equals(this.Role) select rule.Value;


        //    foreach (var button_id in rules.ToList().First())
        //    {
        //        this.buttons[button_id - 1].Enabled = true;
        //    }

        //}

        public int Role { get => role; set => role = value; }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 cot = new Form3();
            cot.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form4 cot = new Form4();
            cot.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form5 cot = new Form5();
            cot.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form6 cot = new Form6();
            cot.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form7 cot = new Form7();
            cot.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form8 cot = new Form8();
            cot.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form9 cot = new Form9();
            cot.ShowDialog();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Form10 cot = new Form10();
            cot.ShowDialog();
        }

        private void glavmenu_Load(object sender, EventArgs e)
        {

        }

        private void glavmenu_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
