﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public SqlConnection GetDBConnection()
        {
            string DB = @"Data Source=DESKTOP-O0P3PUP\SQLEXPRESS;
                    Initial Catalog = t_salon;
                    Integrated Security = True";//Настройка параметров подключения

            SqlConnection connectDB = new SqlConnection(DB);
            connectDB.Open();//Открываем соединение с БД
            return connectDB;
        }

        private int getPostById(int id)
        {
            SqlConnection conn = GetDBConnection();
            SqlCommand sqlcommand = new SqlCommand("SELECT Должность.Код_должности FROM [Данные] JOIN [Должность] on Данные.Должность = Должность.Код_должности where Данные.Код_сотрудника = @Код", conn);

            sqlcommand.Parameters.AddWithValue("@Код", id);

            try
            {
                int result = (int)sqlcommand.ExecuteScalar();

                return result;
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine(ex.Message);
            }

            return -1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            {
                SqlCommand sqlcommand = new SqlCommand();
                SqlConnection conn = GetDBConnection();
                DataSet ds = new DataSet();
                try
                {

                    string table = "Данные";
                    string cell = "Код_сотрудника";
                    sqlcommand = new SqlCommand("SELECT * FROM [Данные] WHERE Логин = @Логин and Пароль = @Пароль", conn);
                    sqlcommand.Parameters.AddWithValue("@Логин", textBox1.Text.ToString());
                    sqlcommand.Parameters.AddWithValue("@Пароль", textBox2.Text.ToString());
                    int id = Convert.ToInt32(sqlcommand.ExecuteScalar());
                    if (id == 0)
                    {
                        MessageBox.Show("Неправильно введен логин или пароль");
                        textBox1.Text = "";
                        textBox2.Text = "";

                    }
                    else
                    {
                        var post = getPostById(id);
                        glavmenu TRV = new glavmenu(post);
                        TRV.Show();
                        conn.Dispose();
                        conn.Close();
                        this.Visible = false;
                    }
                }


                catch (Exception ex)
                {
                    textBox1.Text = "";
                    textBox2.Text = "";
                    MessageBox.Show("Ошибка входа в систему.\nПовторите попытку.");

                }


            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
