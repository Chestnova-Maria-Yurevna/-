﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form10 : Form
    {
        public Form10()
        {
            InitializeComponent();
        }

        private void расходный_материалBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.расходный_материалBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.t_salonDataSet);

        }

        // выполнение запросов с join и заполнение колонок
        private void fillLists()
        {
            Utils.fillList(
                "select Услуги.Наименование_услуг as Услуга from [Расходный_материал] join [Услуги] on Расходный_материал.Наименование_услуг = Услуги.Код_услуги",
                "Услуга",
                расходный_материалDataGridView
                );
            Utils.fillList(
                "select Оборудование.Наименование as Оборудование from [Расходный_материал] join [Оборудование] on Расходный_материал.Код_оборудования = Оборудование.Код_оборудования",
                "Оборудование",
                расходный_материалDataGridView
                );
            Utils.fillList(
                "select Материалы.Наименование as Материал from [Расходный_материал] join [Материалы] on Расходный_материал.Код_материала = Материалы.Код_материала",
                "Материал",
                расходный_материалDataGridView
                );
        }

        private void Form10_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "t_salonDataSet.Расходный_материал". При необходимости она может быть перемещена или удалена.
            this.расходный_материалTableAdapter.Fill(this.t_salonDataSet.Расходный_материал);
            FilterData.fillCombobox(comboBox1, расходный_материалDataGridView);
            fillLists();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.расходный_материалTableAdapter.Fill(this.t_salonDataSet.Расходный_материал);
            fillLists();
        }

        private void queryTextBox_TextChanged(object sender, EventArgs e)
        {
            FilterData.filter(расходный_материалBindingSource, comboBox1, queryTextBox);
        }

        // вызов окна добавления
        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
            // создание объекта FormAdd
            FormAdd formAdd = new FormAdd(расходный_материалBindingSource);
            formAdd.ShowDialog();
            // обновление таблицы
            расходный_материалDataGridView.Update();
            расходный_материалDataGridView.Refresh();
        }
    }
}
