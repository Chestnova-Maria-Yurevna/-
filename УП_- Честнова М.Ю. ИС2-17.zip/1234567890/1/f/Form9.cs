﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
        }

        private void картыBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.картыBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.t_salonDataSet);

        }

        private void Form9_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "t_salonDataSet.Карты". При необходимости она может быть перемещена или удалена.
            this.картыTableAdapter.Fill(this.t_salonDataSet.Карты);
            FilterData.fillCombobox(comboBox1, картыDataGridView);
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            // кнопка обновить
            this.картыTableAdapter.Fill(this.t_salonDataSet.Карты);
        }

        private void queryTextBox_TextChanged(object sender, EventArgs e)
        {
            FilterData.filter(картыBindingSource, comboBox1, queryTextBox);
        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
            FormAdd formAdd = new FormAdd(картыBindingSource);
            formAdd.ShowDialog();
            картыDataGridView.Update();
            картыDataGridView.Refresh();
        }
    }
}
